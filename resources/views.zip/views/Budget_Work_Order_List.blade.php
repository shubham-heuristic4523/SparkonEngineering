@extends('layouts.master')

@section('content')

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0 font-size-18">Budget Work Order List</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="#">Tables</a></li>
                    <li class="breadcrumb-item active">Budget Work Order</li>
                </ol>
            </div>
        </div>
    </div>
</div>

@if(session()->has('message'))
<div class="alert alert-success">{{ session('message') }}</div>
@endif

@if(session()->has('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif

@if($checkForm && $checkForm->write_access == 1)
<div class="mb-3">
    <a href="{{ route('BudgetWorkOrder.create') }}" class="btn btn-primary w-md">Add New Record</a>
</div>
@endif

<div class="card">
    <div class="card-body">
        <table id="datatable-buttons" class="table table-bordered table-striped w-100">
            <thead class="table-light">
                <tr>
                    <th>Sr No</th>
                    <th>Budget No</th>
                    <th>Date</th>
                    <th>Work Order No</th>
                    <th>Client Name</th>
                    <th>Basic Order Value</th>
                    <th>Net Value</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                @foreach($budge as $row)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $row->budget_no }}</td>
                    <td>{{ \Carbon\Carbon::parse($row->date)->format('d-m-Y') }}</td>
                    <td>{{ $row->work_order_no }}</td>
                    <td>{{ $row->ac_name ?? '-' }}</td>
                    <td>{{ number_format($row->basic_order_value, 2) }}</td>
                    <td>{{ number_format($row->net_value, 2) }}</td>

                    <td>
                        @if($checkForm && $checkForm->edit_access == 1)
                        <a href="{{ route('BudgetWorkOrder.edit', $row->budget_no) }}" 
                           class="btn btn-outline-secondary btn-sm" title="Edit">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                        @else
                        <button class="btn btn-outline-secondary btn-sm" disabled title="No Edit Access">
                            <i class="fas fa-lock"></i>
                        </button>
                        @endif
                    </td>

                    <td>
                        @if($checkForm && $checkForm->delete_access == 1)
                        <button class="btn btn-danger btn-sm delete"
                            data-route="{{ route('BudgetWorkOrder.destroy', $row->budget_no) }}"
                            data-token="{{ csrf_token() }}">
                            <i class="fas fa-trash"></i>
                        </button>
                        @else
                        <button class="btn btn-outline-secondary btn-sm" disabled title="No Delete Access">
                            <i class="fas fa-lock"></i>
                        </button>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

<script src="{{ URL::asset('assets/libs/jquery/jquery.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).on('click', '.delete', function(e) {
    e.preventDefault();
    const route = $(this).data('route');
    const token = $(this).data('token');

    Swal.fire({
        title: "Are you sure?",
        text: "This record will be permanently deleted!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Yes, delete it!"
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: route,
                type: "POST",
                data: { _method: 'DELETE', _token: token },
                success: function(response) {
                    Swal.fire("Deleted!", response.message, "success");
                    setTimeout(() => location.reload(), 1500);
                },
                error: function() {
                    Swal.fire("Error!", "Failed to delete record.", "error");
                }
            });
        }
    });
});
</script>

@endsection
