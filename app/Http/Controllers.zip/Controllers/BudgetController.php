<?php

namespace App\Http\Controllers;

use App\Models\Budget_Work_Order_Model;
use App\Models\RawMaterialDetailModel;
use App\Models\ServiceDetailModel;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Exception;

class BudgetController extends Controller
{
   public function index()
{
    try {
        $checkForm = DB::table('form_auth')
            ->where('emp_id', Session::get('userId'))
            ->where('form_id', 26)
            ->first();

        // Join ledger_master to get ac_name based on ac_code
        $budge = DB::table('budget_work_order_master as b')
            ->leftJoin('ledger_master as l', 'b.ac_code', '=', 'l.ac_code')
            ->where('b.delflag', 0)
            ->orderByDesc('b.budget_no')
            ->select('b.*', 'l.ac_name')
            ->get();

        return view('Budget_Work_Order_List', compact('budge', 'checkForm'));
    } catch (Exception $e) {
        Log::error('Budget index error: ' . $e->getMessage());
        return back()->with('error', 'An error occurred while loading the list.');
    }
}

    public function create()
    {
        try {
            $mocs = DB::table('moc_master')
                ->where('delflag', 0)
                ->orderBy('moc_id', 'asc')
                ->get();

            $units = DB::table('unit_master')
                ->where('delflag', 0)
                ->orderBy('unit_id', 'asc')
                ->get();

            $Categories = DB::table('item_category_master')
                ->where('delflag', 0)
                ->orderBy('item_cat_id', 'asc')
                ->get();

                 $approvalStatuses = DB::table('approval_status')
        ->where('delflag', 0) // optional: only active records
        ->pluck('approval_status_name', 'approval_status_id');
        
$Ledgerlist = DB::table('ledger_master')
    ->select('ac_code', 'ac_name')
    ->get();

            // Pass empty collections so blade can use same loops for create/edit
            $RawMaterialDetails = collect();
            $ServiceDetails = collect();

            // IMPORTANT: include $Categories in compact so blade doesn't get undefined variable
            return view('Budget_for_Work_Order', compact('mocs', 'units', 'Categories', 'RawMaterialDetails', 'ServiceDetails','approvalStatuses','Ledgerlist'));
        } catch (Exception $e) {
            Log::error('Budget create error: ' . $e->getMessage());
            return back()->with('error', 'An error occurred while preparing the form.');
        }
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        try {
            $request->validate([
                'date'              => 'required|date',
                'work_order_no'     => 'required|string|max:255',
                'ac_code'       => 'nullable|string|max:255',
                'basic_order_value' => 'nullable|numeric',
                'net_value'         => 'required|numeric',
            ]);

            // Insert master record
            $budgetMaster = Budget_Work_Order_Model::create([
                'date'                      => $request->date,
                'work_order_no'             => $request->work_order_no,
                'ac_code'               => $request->ac_code,
                'basic_order_value'         => $request->basic_order_value ?? 0,
                'net_value'                 => $request->net_value,
                'raw_material_total_cost'   => $request->raw_material_total_cost,
                'service_total_cost'        => $request->service_total_cost,
                'final_total_cost'          => $request->final_total_cost,
                'approval_status_id'           => $request->approval_status_id,
                'comment'                   => $request->comment,
                'userid'                    => Session::get('userId'),
                'delflag'                   => 0,
            ]);

            // Insert raw material rows (separate inputs)
            if ($request->has('raw_item_cat_id')) {
                foreach ($request->raw_item_cat_id as $key => $item_cat_id) {
                    // skip empty rows
                    if (!empty($item_cat_id) || !empty($request->raw_item_discription[$key] ?? '')) {
                        RawMaterialDetailModel::create([
                            'budget_no'        => $budgetMaster->budget_no,
                            'item_cat_id'      => $item_cat_id,
                            'item_discription' => $request->raw_item_discription[$key] ?? '',
                            'moc_id'           => $request->raw_moc_id[$key] ?? null,
                            'qty'              => $request->raw_qty[$key] ?? 0,
                            'unit_id'          => $request->raw_unit_id[$key] ?? null,
                            'rate_in_rs'       => $request->raw_rate_in_rs[$key] ?? 0,
                            'cost'             => $request->raw_cost[$key] ?? 0,
                        ]);
                    }
                }
            }

            // Insert service rows (separate inputs)
            if ($request->has('service_item_cat_id')) {
                foreach ($request->service_item_cat_id as $key => $item_cat_id) {
                    if (!empty($item_cat_id) || !empty($request->service_item_discription[$key] ?? '')) {
                        ServiceDetailModel::create([
                            'budget_no'        => $budgetMaster->budget_no,
                            'item_cat_id'      => $item_cat_id,
                            'item_discription' => $request->service_item_discription[$key] ?? '',
                            'moc_id'           => $request->service_moc_id[$key] ?? null,
                            'qty'              => $request->service_qty[$key] ?? 0,
                            'unit_id'          => $request->service_unit_id[$key] ?? null,
                            'rate_in_rs'       => $request->service_rate_in_rs[$key] ?? 0,
                            'cost'             => $request->service_cost[$key] ?? 0,
                        ]);
                    }
                }
            }

            DB::commit();
            return redirect()->route('BudgetWorkOrder.index')->with('message', 'Record saved successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Budget Work Order store error: ' . $e->getMessage());
            return back()->with('error', 'Error while saving record: ' . $e->getMessage());
        }
    }

    public function edit($id)
    {
        try {
            $BudgetWorkOrder = Budget_Work_Order_Model::findOrFail($id);

            $mocs = DB::table('moc_master')
                ->where('delflag', 0)
                ->orderBy('moc_id', 'asc')
                ->get();

            $units = DB::table('unit_master')
                ->where('delflag', 0)
                ->orderBy('unit_id', 'asc')
                ->get();

            $Categories = DB::table('item_category_master')
                ->where('delflag', 0)
                ->orderBy('item_cat_id', 'asc')
                ->get();

                

                 $approvalStatuses = DB::table('approval_status')
        ->where('delflag', 0) // optional: only active records
        ->pluck('approval_status_name', 'approval_status_id');

       $Ledgerlist = DB::table('ledger_master')
    ->select('ac_code', 'ac_name')
    ->get();


            // Load raw and service details separately
            $RawMaterialDetails = RawMaterialDetailModel::where('budget_no', $id)->get();
            $ServiceDetails = ServiceDetailModel::where('budget_no', $id)->get();

            // include Categories so blade has it when editing
            return view('Budget_for_Work_Order', compact('BudgetWorkOrder', 'mocs', 'units', 'Categories', 'RawMaterialDetails', 'ServiceDetails','approvalStatuses','Ledgerlist'));
        } catch (Exception $e) {
            Log::error('Budget edit error: ' . $e->getMessage());
            return back()->with('error', 'Error while loading record for editing.');
        }
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();

        try {
            $request->validate([
                'date'              => 'required|date',
                'work_order_no'     => 'required|string|max:255',
                'ac_code'       => 'nullable|string|max:255',
                'basic_order_value' => 'nullable|numeric',
                'net_value'         => 'required|numeric',
            ]);

            // Update master record
            Budget_Work_Order_Model::where('budget_no', $id)->update([
                'date'                      => $request->date,
                'work_order_no'             => $request->work_order_no,
                'ac_code'               => $request->ac_code,
                'basic_order_value'         => $request->basic_order_value ?? 0,
                'net_value'                 => $request->net_value,
                'raw_material_total_cost'   => $request->raw_material_total_cost,
                'service_total_cost'        => $request->service_total_cost,
                'final_total_cost'          => $request->final_total_cost,
                'approval_status_id'           => $request->approval_status_id,
                'comment'                   => $request->comment,
                'userid'                    => Session::get('userId'),
            ]);

            // Delete old details and reinsert new raw materials
            RawMaterialDetailModel::where('budget_no', $id)->delete();
            if ($request->has('raw_item_cat_id')) {
                foreach ($request->raw_item_cat_id as $key => $item_cat_id) {
                    if (!empty($item_cat_id) || !empty($request->raw_item_discription[$key] ?? '')) {
                        RawMaterialDetailModel::create([
                            'budget_no'        => $id,
                            'item_cat_id'      => $item_cat_id,
                            'item_discription' => $request->raw_item_discription[$key] ?? '',
                            'moc_id'           => $request->raw_moc_id[$key] ?? null,
                            'qty'              => $request->raw_qty[$key] ?? 0,
                            'unit_id'          => $request->raw_unit_id[$key] ?? null,
                            'rate_in_rs'       => $request->raw_rate_in_rs[$key] ?? 0,
                            'cost'             => $request->raw_cost[$key] ?? 0,
                        ]);
                    }
                }
            }

            // Delete old services and reinsert new service rows
            ServiceDetailModel::where('budget_no', $id)->delete();
            if ($request->has('service_item_cat_id')) {
                foreach ($request->service_item_cat_id as $key => $item_cat_id) {
                    if (!empty($item_cat_id) || !empty($request->service_item_discription[$key] ?? '')) {
                        ServiceDetailModel::create([
                            'budget_no'        => $id,
                            'item_cat_id'      => $item_cat_id,
                            'item_discription' => $request->service_item_discription[$key] ?? '',
                            'moc_id'           => $request->service_moc_id[$key] ?? null,
                            'qty'              => $request->service_qty[$key] ?? 0,
                            'unit_id'          => $request->service_unit_id[$key] ?? null,
                            'rate_in_rs'       => $request->service_rate_in_rs[$key] ?? 0,
                            'cost'             => $request->service_cost[$key] ?? 0,
                        ]);
                    }
                }
            }

            DB::commit();
            return redirect()->route('BudgetWorkOrder.index')->with('message', 'Record updated successfully.');
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Budget update error: ' . $e->getMessage());
            return back()->with('error', 'Error while updating record: ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            Budget_Work_Order_Model::where('budget_no', $id)->update(['delflag' => 1]);
            return response()->json(['success' => true, 'message' => 'Record deleted successfully.']);
        } catch (Exception $e) {
            Log::error('Budget delete error: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Error while deleting record.'], 500);
        }
    }
}