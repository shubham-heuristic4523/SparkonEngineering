<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\ReceiptOfOrderModel;
use App\Models\EnquiryPunchingModel;
use App\Models\LocationModel;
use App\Models\LedgerModel;
use App\Models\ReceiptTaskAllocationModel;
use App\Models\KeyAreaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use Session;
use Exception;

class ReceiptOfOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        try {

            $chekform = DB::table('form_auth')
                ->where('emp_id', Session::get('userId'))
                ->where('form_id', '12')
                ->first();

            $ReceiptOfOrder = ReceiptOfOrderModel::where('receipt_of_order_master.delflag', '=', '0')
                ->get(['receipt_of_order_master.*']);

            return view('ReceiptOfOrderList', compact('ReceiptOfOrder', 'chekform'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function create()
    {
        try {
            $EnquiryNo = EnquiryPunchingModel::where('delflag', '=', '0')->get();
            $LocationList = LocationModel::where('delflag', '=', '0')->get();
            $Ledgerlist = LedgerModel::where('delflag', '=', '0')->get();
            $Keyarealist = KeyAreaModel::where('delflag', '=', '0')->get();
            return view('ReceiptOfOrderMaster', compact('EnquiryNo', 'LocationList', 'Ledgerlist', 'Keyarealist'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function store(Request $request)
    {

        Log::info($request->all());

        $firm_id = $request->input('firm_id');
        dump($firm_id);

        $codefetch = DB::table('counter_number')->select(DB::raw("tr_no + 1 as 'tr_no',c_code,code"))
            ->where('c_name', '=', 'C1')
            ->where('type', '=', 'Receipt_Of_Order')
            ->where('firm_id', '=', $firm_id)
            ->first();

        $TrNo = $codefetch->code . '-' . $codefetch->tr_no;

        try {
            $this->validate($request, [
                'order_confirmation_date' => 'required',
                'enquiry_id' => 'required',
                'estimation_id' => 'required',
                'offer_no' => 'required',
                'client_po_no' => 'required',
                'basic_order_value' => 'required',
                'comments' => 'required',
                'location_of_work_id' => 'required',
                'pdf_link' => 'required',
            ]);

            $userId = Auth::id() ?? session('user_id') ?? 1;

            $input = $request->all();
            $input['Receipt_Of_Order'] = $TrNo; // ✅ Add generated code

            // ✅ Save Master Record
            $receiptoforder = ReceiptOfOrderModel::create([
                'order_confirmation_date' => $request->order_confirmation_date,
                'enquiry_id' => $request->enquiry_id,
                'estimation_id' => $request->estimation_id,
                'offer_no' => $request->offer_no,
                'client_po_no' => $request->client_po_no,
                'basic_order_value' => strip_tags($request->basic_order_value),
                'comments' => $request->comments,
                'location_of_work_id' => strip_tags($request->location_of_work_id),
                'pdf_link' => strip_tags($request->pdf_link),
                'created_by' => $userId,
            ]);

            // ✅ Save Detail Rows
            if ($request->has('key_area_id')) {
                foreach ($request->key_area_id as $key => $key_area_id) {
                    if (!empty($key_area_id)) {
                        ReceiptTaskAllocationModel::create([
                            'receipt_of_order_id' => $receiptoforder->receipt_of_order_id,
                            'key_area_id' => $key_area_id,
                            'assigned_to_id' => $request->assigned_to_id[$key] ?? null,
                        ]);
                    }
                }
            }

            $update = DB::select("update counter_number set tr_no= tr_no + 1   where c_name ='C1' AND type='Enquiry_Punching' AND firm_id=$firm_id");


            return redirect()->route('ReceiptOfOrder.index')
                ->with('message', 'Record saved successfully!');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }




    // public function store(Request $request)
    // {
    //     Log::info($request->all());

    //     $firm_id = $request->input('firm_id');

    //     // ✅ Fetch next transaction number
    //     $codefetch = DB::table('counter_number')
    //         ->select(DB::raw("tr_no + 1 as tr_no, c_code, code"))
    //         ->where('c_name', 'C1')
    //         ->where('type', 'Receipt_Of_Order')
    //         ->where('firm_id', $firm_id)
    //         ->first();

    //     if (!$codefetch) {
    //         return redirect()->back()->with('error', 'Counter number not found for this firm.');
    //     }

    //     $TrNo = $codefetch->code . '-' . $codefetch->tr_no;

    //     try {
    //         $this->validate($request, [
    //             'order_confirmation_date' => 'required',
    //             'enquiry_id' => 'required',
    //             'estimation_id' => 'required',
    //             'offer_no' => 'required',
    //             'client_po_no' => 'required',
    //             'basic_order_value' => 'required',
    //             'comments' => 'required',
    //             'location_of_work_id' => 'required',
    //             'pdf_link' => 'required',
    //         ]);

    //         $userId = Auth::id() ?? session('user_id') ?? 1;

    //         // ✅ Save master record
    //         $receiptoforder = ReceiptOfOrderModel::create([
    //             'order_confirmation_date' => $request->order_confirmation_date,
    //             'enquiry_id' => $request->enquiry_id,
    //             'estimation_id' => $request->estimation_id,
    //             'offer_no' => $request->offer_no,
    //             'client_po_no' => $request->client_po_no,
    //             'basic_order_value' => strip_tags($request->basic_order_value),
    //             'comments' => $request->comments,
    //             'location_of_work_id' => strip_tags($request->location_of_work_id),
    //             'pdf_link' => strip_tags($request->pdf_link),
    //             'created_by' => $userId,
    //             'firm_id' => $firm_id,
    //             'Receipt_Of_Order' => $TrNo,
    //         ]);

    //         // ✅ Save task allocation details
    //         if ($request->has('key_area_id')) {
    //             foreach ($request->key_area_id as $key => $key_area_id) {
    //                 if (!empty($key_area_id)) {
    //                     ReceiptTaskAllocationModel::create([
    //                         'receipt_of_order_id' => $receiptoforder->receipt_of_order_id,
    //                         'key_area_id' => $key_area_id,
    //                         'assigned_to_id' => $request->assigned_to_id[$key] ?? null,
    //                     ]);
    //                 }
    //             }
    //         }

    //         // ✅ Update counter correctly
    //         DB::table('counter_number')
    //             ->where('c_name', 'C1')
    //             ->where('type', 'Receipt_Of_Order')
    //             ->where('firm_id', $firm_id)
    //             ->increment('tr_no');

    //         return redirect()->route('ReceiptOfOrder.index')
    //             ->with('message', 'Record saved successfully!');
    //     } catch (\Exception $e) {
    //         Log::error($e->getMessage());
    //         return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
    //     }
    // }















































    // public function store(Request $request)
    // {
    //     Log::info($request->all());

    //     $firm_id = $request->input('firm_id');

    //     $codefetch = DB::table('counter_number')
    //         ->select(DB::raw("tr_no + 1 as tr_no, c_code, code"))
    //         ->where('c_name', '=', 'C1')
    //         ->where('type', '=', 'Receipt_Of_Order')
    //         ->where('firm_id', '=', $firm_id)
    //         ->first();

    //     if (!$codefetch) {
    //         return redirect()->back()->with('error', 'Counter not configured for this firm. Please check counter_number table.');
    //     }

    //     $TrNo = $codefetch->code . '-' . $codefetch->tr_no;

    //     try {
    //         $this->validate($request, [
    //             'order_confirmation_date' => 'required',
    //             'enquiry_id' => 'required',
    //             'estimation_id' => 'required',
    //             'offer_no' => 'required',
    //             'client_po_no' => 'required',
    //             'basic_order_value' => 'required',
    //             'comments' => 'required',
    //             'location_of_work_id' => 'required',
    //             'pdf_link' => 'required',
    //         ]);

    //         $userId = Auth::id() ?? session('user_id') ?? 1;

    //         $receiptoforder = ReceiptOfOrderModel::create([
    //             'order_confirmation_date' => $request->order_confirmation_date,
    //             'enquiry_id' => $request->enquiry_id,
    //             'estimation_id' => $request->estimation_id,
    //             'offer_no' => $request->offer_no,
    //             'client_po_no' => $request->client_po_no,
    //             'basic_order_value' => strip_tags($request->basic_order_value),
    //             'comments' => $request->comments,
    //             'location_of_work_id' => strip_tags($request->location_of_work_id),
    //             'pdf_link' => strip_tags($request->pdf_link),
    //             'created_by' => $userId,
    //             'Receipt_Of_Order' => $TrNo,
    //         ]);

    //         if ($request->has('key_area_id')) {
    //             foreach ($request->key_area_id as $key => $key_area_id) {
    //                 if (!empty($key_area_id)) {
    //                     ReceiptTaskAllocationModel::create([
    //                         'receipt_of_order_id' => $receiptoforder->receipt_of_order_id,
    //                         'key_area_id' => $key_area_id,
    //                         'assigned_to_id' => $request->assigned_to_id[$key] ?? null,
    //                     ]);
    //                 }
    //             }
    //         }

    //         DB::update("UPDATE counter_number 
    //                 SET tr_no = tr_no + 1 
    //                 WHERE c_name = 'C1' 
    //                   AND type = 'Receipt_Of_Order' 
    //                   AND firm_id = ?", [$firm_id]);

    //         return redirect()->route('ReceiptOfOrder.index')
    //             ->with('message', 'Record saved successfully!');
    //     } catch (\Exception $e) {
    //         Log::error($e->getMessage());
    //         return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
    //     }
    // }




    public function show($receipt_of_order_id)
    {
        try {
            $dip = ReceiptOfOrderModel::find($receipt_of_order_id);
            $isView = "1";
            return view('receipt_of_order_master', compact('dip', 'dip', 'isView'));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function edit($receipt_of_order_id)
    {
        try {
            $EnquiryNo = EnquiryPunchingModel::where('delflag', '=', '0')->get();
            $LocationList = LocationModel::where('delflag', '=', '0')->get();
            $Ledgerlist = LedgerModel::where('delflag', '=', '0')->get();
            $Keyarealist = KeyAreaModel::where('delflag', '=', '0')->get();
            $ReceiptOfOrderList = ReceiptOfOrderModel::findOrFail($receipt_of_order_id);
            $ReceiptTaskAllocationList = ReceiptTaskAllocationModel::where('receipt_of_order_id', $receipt_of_order_id)->get();

            return view('ReceiptOfOrderMaster', compact(
                'EnquiryNo',
                'LocationList',
                'Ledgerlist',
                'Keyarealist',
                'ReceiptOfOrderList',
                'ReceiptTaskAllocationList'
            ));
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $this->validate($request, [
                'order_confirmation_date' => 'required',
                'enquiry_id' => 'required',
                'estimation_id' => 'required',
                'offer_no' => 'required',
                'client_po_no' => 'required',
                'basic_order_value' => 'required',
                'comments' => 'required',
                'location_of_work_id' => 'required',
                'pdf_link' => 'required',
            ]);

            $userId = Auth::id() ?? session('user_id') ?? 1;

            // ✅ Update master
            $ReceiptOfOrder = ReceiptOfOrderModel::findOrFail($id);
            $ReceiptOfOrder->update([
                'order_confirmation_date' => $request->order_confirmation_date,
                'enquiry_id' => $request->enquiry_id,
                'estimation_id' => $request->estimation_id,
                'offer_no' => $request->offer_no,
                'client_po_no' => $request->client_po_no,
                'basic_order_value' => $request->basic_order_value,
                'comments' => strip_tags($request->comments),
                'location_of_work_id' => $request->location_of_work_id,
                'pdf_link' => strip_tags($request->pdf_link),
                'updated_by' => $userId,
            ]);

            // ✅ Delete old task allocation before re-inserting
            ReceiptTaskAllocationModel::where('receipt_of_order_id', $id)->delete();

            if ($request->has('key_area_id')) {
                foreach ($request->key_area_id as $key => $keyAreaId) {
                    if (!empty($keyAreaId)) {
                        ReceiptTaskAllocationModel::create([
                            'receipt_of_order_id' => $id,
                            'key_area_id' => $keyAreaId,
                            'assigned_to_id' => $request->assigned_to_id[$key] ?? null,
                        ]);
                    }
                }
            }

            return redirect()->route('ReceiptOfOrder.index')
                ->with('message', 'Record updated successfully.');
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }


    public function destroy($receipt_of_order_id)
    {
        try {
            ReceiptOfOrderModel::where('receipt_of_order_id', $receipt_of_order_id)
                ->update([
                    'delflag' => 1,
                    'updated_by' => Session::get('userId')
                ]);

            return response()->json(['success' => true, 'message' => 'Record deleted successfully']);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }
}
